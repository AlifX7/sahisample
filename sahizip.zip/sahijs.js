const STORAGE_KEY = "sahityotsav-unit-results-v2";
const EMPTY_TEMPLATE = {
  competitions: []
};

const resultsFile = document.getElementById("results-file");
const saveResultsBtn = document.getElementById("save-results");
const loadDefaultBtn = document.getElementById("load-default");
const editorMessage = document.getElementById("editor-message");
const stats = document.getElementById("stats");
const competitionTiles = document.getElementById("competition-tiles");
const resultViewer = document.getElementById("result-viewer");
const viewerSubtitle = document.getElementById("viewer-subtitle");

let competitions = [];
let selectedCompetitionId = null;
let uploadedPayload = null;

function showMessage(message, isError = false) {
  editorMessage.textContent = message;
  editorMessage.style.color = isError ? "#b42318" : "#6b7285";
}

function safeParse(payload) {
  try {
    return JSON.parse(payload);
  } catch {
    return null;
  }
}

function validateSchema(payload) {
  if (!payload || !Array.isArray(payload.competitions)) return false;

  return payload.competitions.every((item) => {
    const base =
      typeof item.id === "string" &&
      typeof item.name === "string" &&
      typeof item.unit === "string" &&
      typeof item.resultImage === "string";

    if (!base) return false;

    if (item.positions === undefined) return true;
    if (!Array.isArray(item.positions)) return false;

    return item.positions.every(
      (pos) => typeof pos.rank === "string" && typeof pos.name === "string"
    );
  });
}

function getStoredPayload() {
  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) return EMPTY_TEMPLATE;

  const parsed = safeParse(raw);
  if (!validateSchema(parsed)) return EMPTY_TEMPLATE;

  return parsed;
}

function renderStats() {
  const units = new Set(competitions.map((item) => item.unit)).size;
  const withPositions = competitions.filter((item) => Array.isArray(item.positions)).length;

  stats.innerHTML = `
    <article class="stat"><strong>${competitions.length}</strong><span>Total Competitions</span></article>
    <article class="stat"><strong>${units}</strong><span>Units Represented</span></article>
    <article class="stat"><strong>${withPositions}</strong><span>Competitions with Rank Data</span></article>
    <article class="stat"><strong>${selectedCompetitionId ? "1" : "0"}</strong><span>Selected Competition</span></article>
  `;
}

function renderViewer() {
  const selected = competitions.find((item) => item.id === selectedCompetitionId);

  if (!selected) {
    resultViewer.classList.add("empty-state");
    resultViewer.innerHTML = "<p>No competition selected yet.</p>";
    viewerSubtitle.textContent = "Select a competition tile to view";
    return;
  }

  viewerSubtitle.textContent = `${selected.name} • ${selected.unit}`;
  resultViewer.classList.remove("empty-state");

  const positionsHtml = Array.isArray(selected.positions) && selected.positions.length
    ? `<div class="positions"><h5>Top Positions</h5><ul>${selected.positions
        .map((p) => `<li><strong>${p.rank}:</strong> ${p.name}</li>`)
        .join("")}</ul></div>`
    : "";

  resultViewer.innerHTML = `
    <div>
      <img src="${selected.resultImage}" alt="${selected.name} result image" />
      ${positionsHtml}
    </div>
  `;
}

function renderTiles() {
  competitionTiles.innerHTML = "";

  if (!competitions.length) {
    competitionTiles.innerHTML = "<p>No competitions published yet.</p>";
    return;
  }

  competitions.forEach((item) => {
    const tile = document.createElement("button");
    tile.type = "button";
    tile.className = `tile ${item.id === selectedCompetitionId ? "active" : ""}`;
    tile.innerHTML = `
      <h4>${item.name}</h4>
      <p>${item.unit}</p>
      <p class="meta">Click to view official result image</p>
    `;

    tile.addEventListener("click", () => {
      selectedCompetitionId = item.id;
      renderAll();
    });

    competitionTiles.append(tile);
  });
}

function renderAll() {
  renderStats();
  renderTiles();
  renderViewer();
}

function publish(payload) {
  competitions = payload.competitions;
  selectedCompetitionId = competitions[0]?.id || null;
  renderAll();
}

resultsFile.addEventListener("change", async () => {
  const file = resultsFile.files?.[0];
  if (!file) {
    uploadedPayload = null;
    showMessage("No file selected.", true);
    return;
  }

  const text = await file.text();
  const parsed = safeParse(text);

  if (!validateSchema(parsed)) {
    uploadedPayload = null;
    showMessage("Invalid file format. Upload a valid result JSON file.", true);
    return;
  }

  uploadedPayload = parsed;
  showMessage(`File loaded: ${file.name}. Click Publish Uploaded File.`);
});

saveResultsBtn.addEventListener("click", () => {
  if (!uploadedPayload) {
    showMessage("Please upload a valid JSON file before publishing.", true);
    return;
  }

  localStorage.setItem(STORAGE_KEY, JSON.stringify(uploadedPayload));
  publish(uploadedPayload);
  showMessage("Announcement published successfully.");
});

loadDefaultBtn.addEventListener("click", () => {
  uploadedPayload = EMPTY_TEMPLATE;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(EMPTY_TEMPLATE));
  publish(EMPTY_TEMPLATE);
  resultsFile.value = "";
  showMessage("Published data cleared.");
});

const initialPayload = getStoredPayload();
publish(initialPayload);
showMessage("No code editor is shown. Upload official result JSON file to publish.");
